package fire.pb.battle.operate;

import fire.pb.battle.Fighter;

public class DoubleSkillOperate extends DecisionOperate
{

	public DoubleSkillOperate(Fighter fighter)
	{
		super(fighter);
	}
	
	public DoubleSkillOperate(Fighter fighter, xbean.Decision decision)
	{
		super(fighter,decision);
	}

}
