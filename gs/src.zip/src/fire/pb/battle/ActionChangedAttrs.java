package fire.pb.battle;

import java.util.HashMap;
import java.util.Map;

public class ActionChangedAttrs {

	
	private Map<Integer,Map<Integer,Float>> changedAttrs = new HashMap<Integer, Map<Integer,Float>>();

	public Map<Integer, Map<Integer, Float>> getChangedAttrs() {
		return changedAttrs;
	}
	
	
	
}
