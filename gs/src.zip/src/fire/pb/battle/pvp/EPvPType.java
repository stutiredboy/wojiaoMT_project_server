package fire.pb.battle.pvp;

/**
 * PvP类型
 * @author XGM
 */
public enum EPvPType {
	PVP1,
	PVP3,
	PVP5,
}
