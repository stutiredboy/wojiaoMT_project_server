package fire.pb.battle;

public enum EBattleStatsticsType {
     MonsterIDAndNum,
     WinnersOfPlayer,
     MonsterLevelAndNum
}
