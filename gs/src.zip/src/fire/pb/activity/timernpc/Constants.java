package fire.pb.activity.timernpc;

public class Constants {
	/** 定时刷怪活动需求最低等级 */
	public static final int NEED_LEVEL = 30;
	/** 定时刷怪活动id*/
	public static final int ACT_BASE_ID = 200;
	/** 燃烧的军团公告id*/
	public static final int RANSHAOBA_NOTICE_ID = 150222;

}
