package fire.pb.activity.award;

public class ExpBili {
	public final int expweaken;
	public final int expaddition;
	
	public ExpBili(final int expweaken, final int expaddition) {
		this.expweaken = expweaken;
		this.expaddition = expaddition;
	}

}
