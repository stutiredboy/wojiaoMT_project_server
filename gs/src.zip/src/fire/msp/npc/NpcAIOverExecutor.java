package fire.msp.npc;

public abstract class NpcAIOverExecutor {
	
	long npcKey;

	public NpcAIOverExecutor(long npcKey) {
		this.npcKey = npcKey;
	}

	public boolean execute(){
		
		
		return true;
	}
	
}
