package fire.log.beans;

public class ChargeUser {
	
	private int chargeType;
	
	private int chargeValue;
	
	private int userNum;
	
	private int totalNum;
	
	public int getChargeType() {
		return chargeType;
	}

	public void setChargeType(int chargeType) {
		this.chargeType = chargeType;
	}

	public int getChargeValue() {
		return chargeValue;
	}

	public void setChargeValue(int chargeValue) {
		this.chargeValue = chargeValue;
	}

	public int getUserNum() {
		return userNum;
	}

	public void setUserNum(int userNum) {
		this.userNum = userNum;
	}

	public int getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(int totalNum) {
		this.totalNum = totalNum;
	}

}
