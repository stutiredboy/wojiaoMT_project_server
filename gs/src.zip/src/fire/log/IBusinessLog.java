package fire.log;

public interface IBusinessLog {
	public String getLogMsg();
}
