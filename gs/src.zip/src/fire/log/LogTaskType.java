
package fire.log;

public class LogTaskType {
    public static final int SHIMEN = 801;
    public static final int TIANZUN = 802;
    public static final int BOSI_SHANGREN = 803;
    public static final int BANGPAI_JIANSHE = 804;
    public static final int TECHANG = 805;
    public static final int BANGPAI_RICHANG = 806;
    public static final int ZHANYAO_CHUMO = 807;
    public static final int FUQI = 808;
    public static final int ZHUIBU_QIANGDAO = 901;
    public static final int MENPAI_DATI = 902;
    public static final int FENGHUO_TONGMENG = 903;
    public static final int HUNYIN_JIEBAI = 501;
    public static final int CHUANGONG = 502;
    public static final int IMPEXAM = 601;
    public static final int SHENJIMEN = 602;
    public static final int MENPAI_CHUANGUAN = 701;
    public static final int ZHUXIAN_JUQING = 100;
    public static final int ZHIXIAN_JUQING = 200;
}

